import React from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { motion } from "framer-motion";

export default function SeekConnectLanding() {
  return (
    <main className="min-h-screen bg-gradient-to-br from-blue-50 to-teal-100 p-6 flex flex-col items-center justify-center text-center">
      <motion.h1
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8 }}
        className="text-4xl md:text-6xl font-bold mb-4 text-blue-900"
      >
        SeekConnect.ai
      </motion.h1>
      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.4, duration: 0.8 }}
        className="text-lg md:text-xl max-w-xl text-slate-700 mb-6"
      >
        Seek connection with purpose. Forge meaningful friendships, thoughtful companionships, and heartfelt love — powered by the resonance of shared curiosity.
      </motion.p>

      <Card className="max-w-md w-full shadow-xl">
        <CardContent className="p-6 space-y-4">
          <h2 className="text-xl font-semibold">Join the early access list</h2>
          <Input placeholder="Your email address" />
          <Button className="w-full">Notify Me</Button>
        </CardContent>
      </Card>

      <div className="mt-10 text-sm text-slate-500 max-w-md">
        <p>
          Whether you're searching for friendship, companionship, or romantic alignment, SeekConnect helps you discover others who explore life with similar questions, hopes, and dreams. Connection begins with resonance — we help you find it.
        </p>
      </div>
    </main>
  );
}
